-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 
-- Generation Time: Jul 08, 2019 at 12:39 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `book_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `idbuku` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `pengarang` varchar(100) DEFAULT NULL,
  `penerbit` varchar(100) DEFAULT NULL,
  `idkategori` int(11) DEFAULT NULL,
  `imgfile` varchar(100) DEFAULT NULL,
  `sinopsis` text,
  `thnterbit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`idbuku`, `judul`, `pengarang`, `penerbit`, `idkategori`, `imgfile`, `sinopsis`, `thnterbit`) VALUES
(25, 'Sebuah Seni untuk Bersikap Bodo Amat', 'Mark Manson', 'Gramedia', 6, 'download.jfif', 'Kunci dari seni pertama adalah masa bodoh terhadap segala halangan dan perjuangan dalam mencapai sesuatu yang kita inginkan. Seharusnya kita hadapi dan nikmati saja karena dalam mengejar suatu pencapaian, pasti ada saja rintangan yang muncul. Seni kedua, temukan hal-hal penting dan berarti untuk diprioritaskan sehingga kamu bisa lebih mudah untuk masa bodoh pada hal-hal sepele. Adapun seni ketiga mempertegas seni sebelumnya, yakni kita mulai dapat memilah mana yang lebih penting saat beranjak dewasa. Walaupun hal penting itu tampaknya sederhana, tetapi kita bisa tetap bahagia dengan kesederhanaan itu.', 2019),
(26, 'Ikan Terbang', 'yuliana', 'yasaya', 1, '495tropicalfish_100632.png', 'Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang. Sebuah fenomena langka, dimana telah ditemukan ikan bisa terbang', 2017),
(30, 'skripsweetku', 'galih p', 'Univ', 3, 'old-1130738_960_720.jpg', ' emmmmmmmmmmmmmmmmmmmmmmmmmmm  emmmmmmmmmmmmmmmmmmmmmmmmmmm emmmmmmmmmmmmmmmmmmmmmmmmmmm emmmmmmmmmmmmmmmmmmmmmmmmmmm emmmmmmmmmmmmmmmmmmmmmmmmmmm emmmmmmmmmmmmmmmmmmmmmmmmmmm emmmmmmmmmmmmmmmmmmmmmmmmmmmvv', 2014),
(31, '1460 Days', 'yuliana', 'yasaya', 6, 'after-effects-logo.png', ' uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawww uwawwwv uwawww uwawww uwawww uwawww uwawww uwawww', 2014),
(32, 'aku adalah aku', 'Hana', 'ninuninu', 4, 'cara membuat kartun anak sekolah keren abisa.png', 'aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah aku adalah  aku adalah', 2017),
(33, 'Menuju Ramadhan', 'Dini', 'yasaya', 2, '1f2e8-y.jpg', ' Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri Bersihkan Hati Sucikan Diri.', 2018);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `idkategori` int(11) NOT NULL,
  `kategori` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`idkategori`, `kategori`) VALUES
(1, 'Buku Teks'),
(2, 'Majalah'),
(3, 'Skripsi'),
(4, 'Thesis'),
(5, 'Disertasi'),
(6, 'Novel');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Operator');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `fullname`, `role`) VALUES
('admin', '123456', 'Administrator', 'Administrator'),
('Indri', '123', 'Indri Prihatini', 'Operator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`idbuku`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`idkategori`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `idbuku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `idkategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
